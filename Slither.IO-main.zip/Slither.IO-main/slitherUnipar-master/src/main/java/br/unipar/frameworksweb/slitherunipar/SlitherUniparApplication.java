package br.unipar.frameworksweb.slitherunipar;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SlitherUniparApplication {

    public static void main(String[] args) {
        SpringApplication.run(SlitherUniparApplication.class, args);
    }

}
